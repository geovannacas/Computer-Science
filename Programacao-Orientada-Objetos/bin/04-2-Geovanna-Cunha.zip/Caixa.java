// Caixa herda de Funcionario
public class Caixa extends Funcionario {
    protected String horario;

    public Caixa(String nome, String matricula) {
        super(nome, matricula);
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }
}
