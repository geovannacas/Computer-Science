package src;
import java.util.Scanner;

public class ExercLab1_3 {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Entre com a quantidade de cursos que deseja adicionar:");
        int qtd = sc.nextInt();
        sc.nextLine();

        Curso[] cursos = new Curso[qtd];
        for (int i = 0; i < qtd; i++) {

            System.out.println("Entre com o nome do curso " + (i + 1) + ":");
            String nome = sc.nextLine();

            System.out.println("Entre com a carga horaria:");
            int cargaHoraria = sc.nextInt();
            sc.nextLine();

            System.out.println("Entre com o numero de semestres:");
            int numeroDeSemestres = sc.nextInt();
            sc.nextLine();

            System.out.println("Entre com o tipo de turno:");
            String tipoDeTurno = sc.nextLine();

            cursos[i] = new Curso(
                    nome,
                    cargaHoraria,
                    numeroDeSemestres,
                    tipoDeTurno);
        }

        System.out.println("\nInformações dos Cursos Cadastrados:");
        for (int i = 0; i < qtd; i++) {
            System.out.println("\nCurso " + (i + 1) + ":");
            System.out.println("Nome: " + cursos[i].getNome());
            System.out.println("Carga Horária: " + cursos[i].getCargaHoraria() + " horas");
            System.out.println("Número de Semestres: " + cursos[i].getNumeroDeSemestres());
            System.out.println("Turno: " + cursos[i].getTipoDeTurno());
        }

        sc.close();
    }

}
