package src;
import java.util.Scanner;

public class ExercLab1_2 {
        public static void main(String args[]) {
                Scanner sc = new Scanner(System.in);

                System.out.println("Entre com o nome do curso:");
                String nome = sc.nextLine();

                System.out.println("Entre com a carga horaria:");
                int cargaHoraria = sc.nextInt();
                sc.nextLine();

                System.out.println("Entre com o numero de semestres:");
                int numeroDeSemestres = sc.nextInt();
                sc.nextLine();

                System.out.println("Entre com o tipo de turno:");
                String tipoDeTurno = sc.nextLine();

                Curso curso = new Curso(
                                nome,
                                cargaHoraria,
                                numeroDeSemestres,
                                tipoDeTurno);

                System.out.println("Informações do Curso:");
                System.out.println("Nome: " + curso.getNome());
                System.out.println("Carga Horária: " + curso.getCargaHoraria() + " horas");
                System.out.println("Número de Semestres: " + curso.getNumeroDeSemestres());
                System.out.println("Turno: " + curso.getTipoDeTurno());

                sc.close();
        }
}
