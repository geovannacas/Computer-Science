package src;

public class Curso {
	private String nome; 
	private int cargaHoraria;
	private int numeroDeSemestres;
	private String tipoDeTurno;

    public Curso(String nome, int cargaHoraria, int numeroDeSemestres, String tipoDeTurno) {
        this.nome = nome;
        this.cargaHoraria = cargaHoraria;
        this.numeroDeSemestres = numeroDeSemestres;
        this.tipoDeTurno = tipoDeTurno;
    }
    
    public String getNome() {
        return nome;
    }
    
    public int getCargaHoraria() {
        return cargaHoraria;
    }
    
    public int getNumeroDeSemestres() {
        return numeroDeSemestres;
    }
    
    public String getTipoDeTurno() {
        return tipoDeTurno;
    }
}

