#include "tad.h"

int main() {
    int N = 5;

    Aluno exemplos[] = {
        {123, 8.5},
        {456, 7.2},
        {789, 9.0},
        {234, 6.8},
        {567, 8.0}
    };
    
    quickSort(exemplos, 0, N - 1);
    printf("exemplos ordenados por nota:\n");
    for (int i = 0; i < N; i++) {
        printf("Matrícula: %u, Nota: %.2f\n", exemplos[i].Matricula, exemplos[i].Nota);
    }

    printf("\n");

    mergeSort(exemplos, 0, N - 1);
    printf("exemplos ordenados por matrícula:\n");
    for (int i = 0; i < N; i++) {
        printf("Matrícula: %u, Nota: %.2f\n", exemplos[i].Matricula, exemplos[i].Nota);
    }

    return 0;
}
