#include <stdio.h>
#include <stdlib.h>

#define MAX 100

int buscaSequencial(int vet[], int n, int chave, int posicoes[]);
int buscaBinaria(int vet[], int n, int chave, int posicoes[]);

